
package mo1004;


public class Poupanca extends Conta {
    
    private double taxaRendimento;

    public Poupanca(double taxaRendimento, String nomeTitular, double saldo, String numConta, String numCartao, String agencia, String dataAbertura) {
        super(nomeTitular, saldo, numConta, numCartao, agencia, dataAbertura);
        this.taxaRendimento = taxaRendimento;
    }

    public Poupanca() {
        
    }

    public double getTaxaRendimento() {
        return taxaRendimento;
    }

    public void setTaxaRendimento(double taxaRendimento) {
        this.taxaRendimento = taxaRendimento;
    }
    
    @Override
    public void setSaldo(double saldo) {
        this.saldo = saldo + 500;
    }
    
    public double calculoRendimento(double taxa){
        double resultado;
        resultado = taxa * getSaldo();
        return resultado;
    }
    public void mostrarDados(){
        System.out.println("Está uma conta poupança da(o): " + getNomeTitular());
        System.out.println("Possui a seguinte taxa: " + getTaxaRendimento());
        System.out.println("Possui a seguinte taxa: " + getSaldo());
    }
}
