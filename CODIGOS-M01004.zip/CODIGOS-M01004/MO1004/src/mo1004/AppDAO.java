/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package mo1004;

import java.util.List;

/**
 *
 * @author EVERT
 */
public interface AppDAO {
    
    public void salvar(Object registro);
    public void atualizar(Object registro);
    public void deletar(int id);
    public Object buscar(int id);
    public List<Object> listar();
    
    
}
