/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mo1004;

import java.util.List;

/**
 *
 * @author EVERT
 */
public class FuncionarioDAO implements AppDAO{
    @Override
    public void salvar(Object registro) {
        System.out.println("Funcionário salvo!");
    }

    @Override
    public void atualizar(Object registro) {
        System.out.println("Funcionário atualizado!");
    }

    @Override
    public void deletar(int id) {
        System.out.println("Funcionário deletado!");
    }

    @Override
    public Object buscar(int id) {
        System.out.println("Funcionário não encontrado!");
        return null;
    }

    @Override
    public List<Object> listar() {
        System.out.println("Nenhum funcionário cadastrado!");
        return null;
    }

    public void verificarFerias(int id) {
        System.out.println("Funcionário possui 10 dias de férias remuneradas!");
    }
}
