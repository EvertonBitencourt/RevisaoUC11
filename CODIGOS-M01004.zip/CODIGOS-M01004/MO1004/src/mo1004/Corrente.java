
package mo1004;


public class Corrente extends Conta{
    
    private double limite;

    public Corrente(double limite, String nomeTitular, double saldo, String numConta, 
            String numCartao, String agencia, String dataAbertura) {
        super(nomeTitular, saldo, numConta, numCartao, agencia, dataAbertura);
        this.limite = limite;
    }
    
    public Corrente(){
        
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
    
    public void mostrarDados(){
        System.out.println("Está é uma conta correte da(o) " + getNomeTitular());
        System.out.println("Possui o seguinte liimte: " + getLimite());
    }
}
