
package mo1004;

import java.util.Scanner;


public class MO1004 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Corrente cc = new Corrente(1000.0,"Miyuki",10000.0,"1234567","0001", "Senac12345","10/04/2024");
        System.out.println("O limite é:R$ "+ cc.getLimite());
        System.out.println("O nome do titular é:"+ cc.getNomeTitular());
        System.out.println("O saldo é:R$ "+ cc.getSaldo());
        
        Conta [] contas = new Conta[3];
        contas[0] = new Corrente(500.0,"Kevin",5000.0,"223456789","0001", "Senac12345","11/04/2024");
        contas[1] = new Poupanca(0.5,"Miyuki",10000.0,"1234567","0001", "Senac12345","10/04/2024");
        contas[2] = cc;
        
        Scanner teclado = new Scanner(System.in);
        for(Conta conta : contas){
            //System.out.println("O limite é:R$ "+ conta.getLimite());
            //System.out.println("O saldo é:R$ "+ conta.getSaldo());
            //System.out.println("O nome do titular é:"+ conta.getNomeTitular());
            if(conta instanceof Poupanca){
                Poupanca poupanca = (Poupanca) conta;
                /* System.out.println("Taxa de Rendimento: " + poupanca.getTaxaRendimento());
                System.out.println("Informe uma taxa");
                double taxa = teclado.nextDouble();
                System.out.println("O valor de Rendimento é : " + poupanca.calculoRendimento(taxa));*/
                poupanca.setSaldo(poupanca.getSaldo());
                conta.mostrarDados();
        }else if(conta instanceof  Corrente){
                /*Corrente corrente = (Corrente) conta;
                System.out.println("Taxa de Rendimento: " + corrente.getLimite());*/
                conta.mostrarDados();
                }
        }
    }    
}
