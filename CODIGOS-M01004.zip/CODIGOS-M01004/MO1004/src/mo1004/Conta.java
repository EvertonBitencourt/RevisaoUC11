/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mo1004;

/**
 *
 * @author EVERT
 */
public abstract class Conta {
    private String nomeTitular; 
    protected double saldo;
    private String numConta;
    private String numCartao;
    private String agencia;
    private String dataAbertura;

    public Conta(String nomeTitular, double saldo, String numConta, String numCartao, 
            String agencia, String dataAbertura) {
        this.nomeTitular = nomeTitular;
        this.saldo = saldo;
        this.numConta = numConta;
        this.numCartao = numCartao;
        this.agencia = agencia;
        this.dataAbertura = dataAbertura;
    }

    public Conta() {
    }

    public String getNomeTitular() {
        return nomeTitular;
    }

    public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String getNumConta() {
        return numConta;
    }

    public void setNumConta(String numConta) {
        this.numConta = numConta;
    }

    public String getNumCartao() {
        return numCartao;
    }

    public void setNumCartao(String numCartao) {
        this.numCartao = numCartao;
    }

    public String getAgencia() {
        return agencia;
    }

    public void setAgencia(String agencia) {
        this.agencia = agencia;
    }

    public String getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(String dataAbertura) {
        this.dataAbertura = dataAbertura;
    }
    
    public abstract void mostrarDados();
}
