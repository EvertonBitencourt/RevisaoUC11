/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exemplopolimorfismo;

/**
 *
 * @author EVERT
 */
public class ExemploPolimorfismo {

    
    public static void main(String[] args) {
        Animal cachorro = new Cachorro();
        Animal pato = new Pato();
        Animal gato = new Gato();
        Animal pessoa = new Pessoa();
        
        cachorro.falar();
        pato.falar();
        gato.falar();
        pessoa.falar();
        
    }
}
