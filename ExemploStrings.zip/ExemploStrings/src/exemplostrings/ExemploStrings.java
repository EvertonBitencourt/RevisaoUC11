package exemplostrings;


import java.util.Scanner;

public class ExemploStrings {
    public static void main(String[] args) {
        String texto;
        texto = "Boa noite";
        System.out.println("A frase: "+ texto + " possui "+
                texto.length() + " caracteres");
        
        System.out.println("A função toLowerCase transforma "
                + "o texto em caracteres minusculos como na "
                + "seguinte frase: "+ texto.toLowerCase());
        System.out.println("A função toUpperCase, transforma "
                + "o texto em caracteres maiusculos como na"
                + "seguinte frse" + texto.toUpperCase());
        
        String texto1 = "aNão";
        if(texto1.contains("Não")){
            System.out.println("o Conteúdo da variavel texto1 é: "
            + texto1);
        }
        Scanner teclado = new Scanner (System.in);
        String texto2;
        do{
            System.out.println("Digite alguma coisa: ");
            texto2 = teclado.nextLine();
        }while (texto2.isEmpty());
        System.out.println("O texto informado foi: " + texto2);
     
        String nome = "Everton Bitencourt", primeiroNome;
        int tamanhoNome, escape;
        tamanhoNome = nome.length();
        escape = nome.indexOf(" ");
        primeiroNome = nome.substring(0, escape);
        System.out.println("O nome possui " + tamanhoNome + ""
                + " caracteres e o primeiro nome é: " + primeiroNome);
        
        //casting é a capacidade de alterar o tipo de dado de uma variavel
        double valor = 10.5;
        int valorCasting = (int) valor;
        System.out.println(valorCasting);
    }
}
